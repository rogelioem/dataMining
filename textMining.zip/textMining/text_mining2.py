#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 27 18:18:46 2018

@author: rogelio
"""

import glob
import io
from textblob import TextBlob
path = 'speeches/*.txt' #note C:
files = glob.glob(path)
from collections import Counter
from string import punctuation
import pandas as pd

###Function that retrieves the coverage between 2 terms and its term-Doc frequency matrix
def coverage(m,a,b):
    cov = 0
    for row in range(len(m)):
        if(m.iloc[row][a] == 1) and (m.iloc[row][b] == 1):
            cov = cov + 1
    return "Coverage %s --> %s : %s" %(a,b,cov)

###Function that retrieves the accuracy between 2 terms and its term-Doc frequency matrix
def accuracy(m,a,b):
    denom = 0
    num = 0
    for row in range(len(m)):
        if(m.iloc[row][a] == 1):
            denom = denom +1
            if(m.iloc[row][b] == 1):
                num = num + 1
    return "Accuracy %s --> %s : %s/%s" %(a,b,num,denom)

### Clean wordlist beyond punctuaction and weird symbols that were not providing useful information
def c2(word):
    if any((c in set(punctuation)) for c in word):
        return False
    if (u'\u2019' == word) or (u'\u2013' == word) or (u'\u2014' == word):
        return False
    return True

### Initialization of stopwords array
stop_words2 = []
with open("english-stop-words-large.txt",'r') as myfile:
    stop_words=myfile.readlines()
    for w in stop_words:
        w = w.replace('\n', '')
        stop_words2.append(w)

### Adding extra stopwords 
stop_words2.append("applause")
stop_words2.append("applpause")

### Files to compare
files_trump = ["speeches/trump10.txt","speeches/trump20.txt","speeches/trump30.txt","speeches/trump40.txt","speeches/trump50.txt","speeches/trump60.txt","speeches/trump70.txt"]
files_clinton = ["speeches/clinton20.txt","speeches/clinton25.txt","speeches/clinton30.txt","speeches/clinton35.txt","speeches/clinton40.txt","speeches/clinton50.txt","speeches/clinton55.txt"]
wordlists = []
filenames= []
texts = ""

#### Generating a single text file with all text from all speeches from a single politician
#for name in files_trump:
for name in files_clinton:
    filenames.append(name)
    with io.open(name,'r',encoding='utf8') as f:
        text = f.read()
        texts = texts+text
        txtblb = TextBlob(text)
        wordlist = txtblb.words
        new_wordlist = [w2 for w2 in wordlist.lower() if ((w2 not in stop_words2) and c2(w2))]
        wordlists.append(new_wordlist)

wordlist2 = TextBlob(texts).words
new_wordlist2 = [w2 for w2 in wordlist2.lower() if ((w2 not in stop_words2) and c2(w2))]

###Getting most common words uses by a politician in all his/her speeches
#print new_wordlist2
cnt = Counter(new_wordlist2)
mcw2 = cnt.most_common(3)
print mcw2

term_doc = []
set_matrix = [term[0] for term in mcw2]

### Generating new term-Doc frequency matrix
for i,blob in enumerate(wordlists):
    dic = {}
    dic["Name"] = filenames[i]
    for term2 in set_matrix:
        if term2 in blob:
            dic[term2] = 1
        else:
            dic[term2] = 0
    term_doc.append(dic)
set_matrix2 = ["Name"].append(set_matrix)
matrix2 = pd.DataFrame(term_doc, columns = set_matrix2)
print matrix2
print 

### applying associaton rules to the term-doc freq matrix
for t1 in set_matrix:
    for t2 in set_matrix:
        if t1 != t2:
            print coverage(matrix2,t1,t2)
            print accuracy(matrix2,t1,t2)
            print


