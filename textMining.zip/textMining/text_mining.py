#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 20 20:09:25 2018

@author: rogelio
"""

import glob
import io
from textblob import TextBlob
path = 'speeches/*.txt' #note C:
files = glob.glob(path)
from collections import Counter
from string import punctuation
import math
import pandas as pd
from sklearn.metrics import pairwise_distances
#from scipy.spatial.distance import cosine

def c2(word):
    if any((c in set(punctuation)) for c in word):
        return False
    if (u'\u2019' == word) or (u'\u2013' == word) or (u'\u2014' == word):
        return False
    return True

def docs_containing(word, bloblist):
    return sum(1 for blob in bloblist if word in blob.words)

def idf(word, bloblist):
    r = float(len(bloblist)+0.5)/(0.5+docs_containing(word, bloblist))
    return math.log(r)

def tf(word, blob):
    return blob.words.count(word) / len(blob.words)

def tfidf(word, blob, bloblist):
    return tf(word, blob) * idf(word, bloblist)

stop_words2 = []
with open("english-stop-words-large.txt",'r') as myfile:
    stop_words=myfile.readlines()
    for w in stop_words:
        w = w.replace('\n', '')
        stop_words2.append(w)
    
stop_words2.append("applause")
stop_words2.append("applpause")
bloblist = []
doc_dicts = []

###Generating a dictionary for each file and appending it to a list of dictionaries
for name in files:
    wordlist = []
    with io.open(name,'r',encoding='utf8') as f:
        text = f.read()
        txtblb = TextBlob(text)
        bloblist.append(txtblb)
        wordlist = txtblb.words
    
    new_wordlist = [w2 for w2 in wordlist.lower() if ((w2 not in stop_words2) and c2(w2))]

    cnt = Counter(new_wordlist)

    mcw = new_wordlist.count(cnt.most_common(1)[0][0])
                
    dic = {}
    dic["Name"] = name
    dic["Total_words"] = len(new_wordlist)
    dic["Polarity"] = txtblb.sentiment.polarity
    dic["Subjectivity"] = txtblb.sentiment.subjectivity
    dic["MostCommonWord"] = cnt.most_common(1)[0][0]
    dic["NormalizedMCW"] = float(mcw)/len(new_wordlist)
    dic["FrequencyMCW"] = cnt.most_common(1)[0][1]
    dic["wordlist"] = new_wordlist
    doc_dicts.append(dic)

for dic in doc_dicts:
    dic["IDF"] = idf(dic["MostCommonWord"], bloblist)
    dic["TFIDF"] = idf(dic["MostCommonWord"], bloblist)*dic["FrequencyMCW"]

###Appending list of dictionaries to my Matrix
matrix = pd.DataFrame(doc_dicts, columns = ["Name","Total_words","Polarity","Subjectivity","MostCommonWord","NormalizedMCW","FrequencyMCW","IDF","TFIDF"])
print matrix

term_doc = []
set_matrix = list(set(matrix["MostCommonWord"]))

### Generating dictionaries that contain the term-doc frequency data
for dic in doc_dicts:
    dic2 = {}
    dic2["Name"] = dic["Name"]
    for w in set_matrix:
        if w in dic["wordlist"]:
            dic2[w] = 1
        else:
            dic2[w] = 0
    term_doc.append(dic2)

### Appending the dictionaries to my Dataframe containing term-Freq Data
set_matrix2 = ["Name"].append(set_matrix)
matrix2 = pd.DataFrame(term_doc, columns = set_matrix2)
matrix3 = matrix2.drop("Name", axis=1)
matrix4 = matrix3.as_matrix()

print matrix2
print matrix3
print matrix4
cosine_distances = pairwise_distances(matrix4, metric="cosine")
print "Cosine Distance Matrix"
print cosine_distances





