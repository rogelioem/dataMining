#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 28 12:04:54 2018

@author: rogelio
"""

import numpy as np
import imageio
import matplotlib.pyplot as plt
from skimage import feature

def weightedAverage(pixel):
    return 0.299*pixel[0] + 0.587*pixel[1] + 0.114*pixel[2]

def rgb2bw(pixel):
    if pixel >= 128:
        return 255
    else:
        return 0 

def threshold_canny(image):
    im = imageio.imread(image)
    im_grey = np.zeros((im.shape[0], im.shape[1])) # init 2D numpy array
    im_bw = np.zeros((im.shape[0], im.shape[1])) # init 2D numpy array

    ###Converting to Greyscale
    for rownum in range(len(im)):
        for colnum in range(len(im[rownum])):
            im_grey[rownum][colnum] = weightedAverage(im[rownum][colnum])
    
    ###Converting to Black&White      
    for rownum in range(len(im)):
        for colnum in range(len(im[rownum])):
            im_bw[rownum][colnum] = rgb2bw(im_grey[rownum][colnum])
    
    ###Applying canny edge filter.
    edge = feature.canny(im_bw, sigma=3)
    edge2 = edge.astype(int)
    
    return (im_bw,edge2,im_grey,im)

def normalized_difference_score(binaries,edges):
    ###Computing normalized difference score
    num_diff_binaries = 0
    num_diff_edges = 0
    for row in range(len(binaries[0])):
        for col in range(len(binaries[0][row])):
            if binaries[0][row][col] != binaries[1][row][col]:
                num_diff_binaries = num_diff_binaries + 1
            if edges[0][row][col] != edges[1][row][col]:
                num_diff_edges = num_diff_edges + 1

    pixel_diff_binaries = float(num_diff_binaries)/(100*100)
    pixel_diff_cannyf = float(num_diff_edges)/(100*100)
    
    return (pixel_diff_binaries, pixel_diff_cannyf)

kiwi1 = 'fruits/kiwi/0_100.jpg'
banana1 = 'fruits/banana/0_100.jpg'
images = [kiwi1, banana1]

binaries = []
edges = []

for image in images:
    t = threshold_canny(image)

    binaries.append(t[0])
    edges.append(t[1])
    
    fig, axes = plt.subplots(ncols=4, figsize=(8, 2.5))
    ax = axes.ravel()
 
    ###Displaying images
    ax[0].imshow(t[3])
    ax[0].set_title('Original')
    ax[0].axis('off')

    ax[1].imshow(t[2], cmap=plt.cm.gray)
    ax[1].set_title('GreyScale')
    ax[1].axis('off')
    
    ax[2].imshow(t[0], cmap=plt.cm.gray)
    ax[2].set_title('Thresholded')
    ax[2].axis('off')
    
    ax[3].imshow(t[1], cmap=plt.cm.gray)
    ax[3].set_title('Canny Filter $\sigma=3$')
    ax[3].axis('off')
    
    plt.show()
    
###Computing difference between Black&White images
bw_diff = abs(binaries[0]-binaries[1])
edges_diff = abs(edges[0]-edges[1])

fig, axes = plt.subplots(ncols=2, figsize=(8, 2.5))
ax = axes.ravel()

ax[0].imshow(bw_diff, cmap=plt.cm.gray)
ax[0].set_title('Black&White Diff')
ax[0].axis('off')

ax[1].imshow(edges_diff, cmap=plt.cm.gray)
ax[1].set_title('Canny filter Diff')
ax[1].axis('off')

plt.show()


t = normalized_difference_score(binaries,edges)
print "Thresholding differences: %s" %t[0]
print "Canny Edge differences: %s" %t[1]

