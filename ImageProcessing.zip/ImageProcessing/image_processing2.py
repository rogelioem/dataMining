#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Apr  8 19:17:32 2018

@author: rogelio
"""

from skimage import feature
import glob
import pandas as pd
import numpy as np
import imageio

def weightedAverage(pixel):
    return 0.299*pixel[0] + 0.587*pixel[1] + 0.114*pixel[2]

def rgb2bw(pixel):
    if pixel >= 128:
        return 255
    else:
        return 0 

def threshold_canny(image):
    im = imageio.imread(image)
    im_grey = np.zeros((im.shape[0], im.shape[1])) # init 2D numpy array
    im_bw = np.zeros((im.shape[0], im.shape[1])) # init 2D numpy array

    ###Converting to Greyscale
    for rownum in range(len(im)):
        for colnum in range(len(im[rownum])):
            im_grey[rownum][colnum] = weightedAverage(im[rownum][colnum])
    
    ###Converting to Black&White      
    for rownum in range(len(im)):
        for colnum in range(len(im[rownum])):
            im_bw[rownum][colnum] = rgb2bw(im_grey[rownum][colnum])
    
    ###Applying canny edge filter.
    edge = feature.canny(im_bw, sigma=3)
    edge2 = edge.astype(int)
    
    return (im_bw,edge2,im_grey,im)

def normalized_difference_score(binaries,edges):
    ###Computing normalized difference score
    num_diff_binaries = 0
    num_diff_edges = 0
    for row in range(len(binaries[0])):
        for col in range(len(binaries[0][row])):
            if binaries[0][row][col] != binaries[1][row][col]:
                num_diff_binaries = num_diff_binaries + 1
            if edges[0][row][col] != edges[1][row][col]:
                num_diff_edges = num_diff_edges + 1

    pixel_diff_binaries = float(num_diff_binaries)/(100*100)
#    print "Thresholding difference score: %s" %pixel_diff_binaries

    pixel_diff_cannyf = float(num_diff_edges)/(100*100)
#    print "Canny filter difference score: %s" %pixel_diff_cannyf
    
    return (pixel_diff_binaries, pixel_diff_cannyf)



path = 'fruits/*' #note C:
clusters = glob.glob(path)
black_whites = []
cannyEdges = []
for cluster in clusters:
    cluster = cluster+"/*.jpg"
    cluster_path = glob.glob(cluster)
    fruits = []
    for image in cluster_path:
        t = threshold_canny(image)
        black_whites.append(t[0])
        cannyEdges.append(t[1])
        


def forloco(x, serie):
    t_a = []
    for j in range(0,len(serie)):
        t = normalized_difference_score([x,serie[j]],[x,serie[j]])
        t_a.append(t[0])
    media = np.mean(t_a)
    return media

series_thresholding = pd.Series(black_whites)
s4 = series_thresholding.apply(forloco, args=(series_thresholding,))

series_cannyEdge = pd.Series(cannyEdges)
s5 = series_cannyEdge.apply(forloco, args=(series_cannyEdge,))
        
print "mean_thresholding: %s" %np.mean(s4)
print "mean_cannyEdge: %s" %np.mean(s5)
